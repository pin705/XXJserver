<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8" content="width=device-width,user-scalable=no" name="viewport">
	<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
    <title>Tầm Duyên nhớ</title>
    <link rel="stylesheet" href="/cs/css/gamecss.css">
	
</head>
<body>
<div class="main">

<div align="center">Địa đồ tường tình:</div>
<div class="dtjd">
<IMG width="100%" height="100%" src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201708%2F05%2F20170805180947_zBrHd.thumb.700_0.gif&refer=http%3A%2F%2Fb-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1641450712&t=541389b79b5fad5a549c99b0e488668a"></div>


	  
	  
       <!--<a href="?cmd=Yc2x1pkhPpWdvbWlkJm5ld21pZD0zMDAmc2lkPTExMTExMQO0O0OO0O0O" >[Quay đầu bờ]Bỉ Ngạn Hoa</a>--><br/><br>
<br>
<a href="#" onClick="javascript:history.back(-1);">Trở lại</a><br/>
<a href="javascript:history.back(-1);">Trở về trò chơi</a></div>
</body>
<div class="footer">
<footer>
    <script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
	<script>
	function changetime(){
	var ary = Array("Chủ Nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy");
	var Timehtml = document.getElementById('CurrentTime');
	var date = new Date();
	Timehtml.innerHTML = ''+date.toLocaleString()+' '+ary[date.getDay()];
	}
	window.onload = function(){
	changetime();
	setInterval(changetime,1000);
	}
	</script>
	<div id="CurrentTime">2021-12-07 13:50:52</div>
</footer>
</div>
</html>